package com.vani.canvas.App;

import java.util.Scanner;

import com.vani.canvas.draw.Canvas;
import com.vani.canvas.draw.Command;
import com.vani.canvas.exception.InvalidInputException;

public class Application {
    public static void main(String[] args) {
      
    	
    	printMenu();
        try
        {
        Scanner scanner = new Scanner(System.in);
        
        Command cmdProcessor = new Command();
        while(true)
        {
        	System.out.print("Enter command: ");
        
       
            String line = scanner.nextLine().trim();
            String[] cmd = line.split("\\s+");
            try {
                cmdProcessor.process(cmd);
                Canvas canvas = cmdProcessor.getCanvas();
                if (canvas != null) {
                   canvas.display();
                }
            } catch (InvalidInputException iie) {
				System.err.println(iie.getMessage());
			}
		
        }
	} catch (Exception e) {
		e.printStackTrace();
	}
        }
    
    private static void printMenu() {
		String menu = "The work as follows:\n"
				+ "1. Create a new canvas \n"
				+ "2. Draw on the canvas by issuing various commands \n"
				+ "3. Quit \n\n\n"
				+ "|Command 		|Description|\n"
				+ "|----|----|\n"
				+ "|C w h          | Create a new canvas of width w and height h.|\n"
				+ "|L x1 y1 x2 y2  | Draw a new line from (x1,y1) to (x2,y2). Currently, only|\n"
				+ "|               | horizontal or vertical lines are supported. Horizontal and vertical lines|\n"
				+ "|               | will be drawn using the 'x' character.|\n"
				+ "|R x1 y1 x2 y2  | Draw a rectangle whose upper left corner is (x1,y1) and|\n"
				+ "|               | lower right corner is (x2,y2). Horizontal and vertical lines will be drawn|\n"
				+ "|               | using the 'x' character.|\n"
				+ "|B x y c        | Fill the entire area connected to (x,y) with \"colour\" c. The|\n"
				+ "|               | behaviour of this is the same as that of the \"bucket fill\" tool in paint|\n"
				+ "|               | programs.|\n"
				+ "|Q              | Quit|\n";
		System.out.println(menu);
	}
    
    
    }

