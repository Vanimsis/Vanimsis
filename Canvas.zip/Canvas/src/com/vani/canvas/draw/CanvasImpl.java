
package com.vani.canvas.draw;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;

import com.vani.canvas.model.Pixels;
import com.vani.canvas.model.PixelsPrinter;
import com.vani.canvas.validation.Validation;
import com.vani.canvas.exception.InvalidInputException;

public class CanvasImpl implements Canvas {

    private static final char EMPTY_CHAR = ' ';
    private static final char H_EDGE_CHAR = '-';
    private static final char V_EDGE_CHAR = '|';
    private static final char LINE_CHAR ='x';
    private final int width;
    private final int height;
    private final char[][] pixels;
    Validation v=new Validation();
    public CanvasImpl(int width, int height) {

        if (width <= 0 || height <= 0) {
            throw new IllegalArgumentException("canvas width and height must be positive value");
        }
        this.width = width+2;
        this.height = height+2;
        pixels = new char[this.height][this.width];
        init();
    }

	/*
	 * public CanvasImpl(char[][] pixels) { this.width = pixels[0].length;
	 * this.height = pixels.length; this.pixels = pixels; }
	 */
    @Override
    public void drawLine(int x1, int y1, int x2, int y2) {
        try
        {
    	int lwidth[]= {x1,x2};
    	int lheight[]= {y1,y2};
    	
    	v.validatePositiveParams(x1, y1, x2, y2);
        v.validateWidthRange(lwidth,width);
        v.validateHeightRange(lheight,height); 
       
        if (x1 == x2) {
            fillVerticalLine(x1, y1, y2, LINE_CHAR);
        } else if (y1 == y2) {
            fillHorizontalLine(y1, x1, x2, LINE_CHAR);
        } else {
            throw new UnsupportedOperationException();
        }
        }
        catch (Exception iie) {
			System.err.println(iie.getMessage());
		}
        
    }

    @Override
    public void drawRect(int x1, int y1, int x2, int y2) {
    	
    	int lwidth[]= {x1,x2};
    	int lheight[]= {y1,y2};
    	try
    	{
    	v.validatePositiveParams(x1, y1, x2, y2);
        v.validateWidthRange(lwidth,width);
        v.validateHeightRange(lheight,height); 
        v.validateRightGreaterThanLeft(x1, x2);
        v.validateRightGreaterThanLeft(y1, y2);
        fillHorizontalLine(y1, x1, x2, LINE_CHAR);
        fillHorizontalLine(y2, x1, x2, LINE_CHAR);
        fillVerticalLine(x1, y1+1, y2-1, LINE_CHAR);
        fillVerticalLine(x2, y1+1, y2-1, LINE_CHAR);
    	}
    	catch (Exception iie) {
			System.err.println(iie.getMessage());
		}
    }

    @Override
    public void fill(int x, int y, char color) {
    	int lwidth[]= {x};
    	int lheight[]= {y};
    	try
    	{
    	
    	
    	v.validatePositiveParams(x, y);
        v.validateWidthRange(lwidth, width);
        v.validateHeightRange(lheight,height); 
        Queue<Pixels> queue = new LinkedList<Pixels>();
        queue.add(new Pixels(x, y));
        while (!queue.isEmpty()) {
            
            fillColor(queue, color);
        }
    	}
    	catch (Exception iie) {
			System.err.println(iie.getMessage());
		}
    }

    @Override
    public void display() {
        PixelsPrinter.printLines(pixels);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CanvasImpl canvas = (CanvasImpl) o;
        return Arrays.deepEquals(pixels, canvas.pixels);
    }

    @Override
    public int hashCode() {
        return Arrays.hashCode(pixels);
    }

   

   

    
    private void init() {
        for (char[] line : pixels) {
            Arrays.fill(line, EMPTY_CHAR);
        }
        fillHorizontalLine(0, 0, width-1, H_EDGE_CHAR);
        fillHorizontalLine(height-1, 0, width-1, H_EDGE_CHAR);
        fillVerticalLine(0, 1, height-2, V_EDGE_CHAR);
        fillVerticalLine(width-1, 1, height-2, V_EDGE_CHAR);
    }

   
    private void fillHorizontalLine(int y, int begin, int end, char p) {
        fillLine(y, begin, end, p, true);
    }

    private void fillVerticalLine(int x, int begin, int end, char p) {
        fillLine(x, begin, end, p, false);
    }

    private void fillLine(int fixed, int begin, int end, char p, boolean horizontal) {
    	//System.out.println("Inside fillLine &&&&&&"+begin+"  "+end+"  "+p+"  "+horizontal);
        if (begin > end) {
        	System.out.println("begin>end");
            // swap begin and end
            begin = begin+end;
            end = begin-end;
            begin = begin-end;
            System.out.println("begin&&&&&&&"+begin+"end&&&&&&&&&"+end);
        }
        for(int i=begin; i<=end; i++) {
            if (horizontal) {
                pixels[fixed][i] = p;
            } else {
                pixels[i][fixed] = p;
            }

        }
    }

    private void fillColor(Queue<Pixels> queue, char color) {
        Pixels node = queue.remove();
        int x = node.getX();
        int y = node.getY();
        char currentColor = pixels[y][x];
        if (color == currentColor) {
            return;
        }
        int w  = x;
        int e  = w;
        while (w>1 && pixels[y][w-1]==currentColor) {
            --w;
        }

        while (e<this.width && pixels[y][e+1]==currentColor) {
            ++e;
        }

        for(int i=w; i<=e; i++) {
            pixels[y][i] = color;
            if ( pixels[y -1][i]==currentColor) {
                queue.add(new Pixels(i, y - 1));
            }
            if ( pixels[y +1][i]==currentColor) {
                queue.add(new Pixels(i, y + 1));
            }
        }
    }
}
