package com.vani.canvas.validation;

import com.vani.canvas.exception.InvalidInputException;

public class Validation
{
	

    public void validateRightGreaterThanLeft(int left, int right) throws InvalidInputException {
        if (left >= right) {
            throw new InvalidInputException("coordinate positions are wrong: (" + left + ", " + right + ")");
        }
    }

    
    public void validatePositiveParams(int... parameters) throws InvalidInputException {
        for (int parameter : parameters) {
            if (parameter <= 0) {
                throw new InvalidInputException("parameter must be positive number: " + parameter);
            }
        }
    }
   

	

	public void validateWidthRange(int[] widthparameters, int width) throws InvalidInputException {
		for (int parameter : widthparameters) {
            if (parameter > width - 2) {
                throw new InvalidInputException("parameter out of canvas width: " + parameter);
           
               
            }
        }
		
	}

	public void validateHeightRange(int[] lheight, int height) throws InvalidInputException {
		for (int parameter : lheight) {
            if (parameter > height - 2) {
                throw new InvalidInputException("parameter out of canvas height: " + parameter);
            }
        }
		
	}
}
